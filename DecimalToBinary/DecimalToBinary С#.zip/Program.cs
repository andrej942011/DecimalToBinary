﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecimalToBinary
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] arrBoolean = new int[5];
            //uint value = 25; //25; //00011001//вводимое знач
            //uint mask = 1;

            //for (int i = arrBoolean.Length - 1; i >= 0; i--)
            //{
            //    //var t = value & mask;
            //    if ((value & mask) == mask)
            //    {
            //        arrBoolean[i] = 1;
            //    }
            //    else
            //        arrBoolean[i] = 0;

            //    //побитовый сдивг
            //    mask = mask << 1;
            //    Console.WriteLine(mask);
            //}

            //for (int i = 0; i < arrBoolean.Length; i++)
            //{
            //    Console.Write(arrBoolean[i]);
            //}
            //Console.ReadKey();
            Console.WriteLine("Введите число");
            string st = Console.ReadLine();
            char[] arrCh = st.ToCharArray();//new[] {'1', '2'};
            int znach = atoi(arrCh);

            Console.WriteLine(convertToBinnary(znach));

            Console.ReadKey();
        }

        public static int atoi(char[] str)
        {
            int res = 0; //значение результата

            //склейка чисел
            for (int i = 0; i < str.Length; i++) //str[i] != '\0'
            {
                res = res * 10 + str[i] - '0';
            }

            return res;
        } 

        public static string convertToBinnary(int n)
        {
            //int n = znach;
            int k = 0;
            string arr = "";

            

            while (n > 0)
            {
                //5%2 = 5-2=3-2=1, 1 < 2. Ответ 1.
                int znach = n;

                //проверка на остатток от деления
                while (znach > 1)
                    znach = znach - 2;

                arr += znach.ToString();

                n = n / 2;
            }

            //while (a!=0)
            //{
            //    a /= 2;
            //    k++;
            //}

            //рабоч
            //while (n != 0)
            //{
            //    if (n % 2 == 0)
            //        arr += "0";
            //    else
            //        arr += "1";
            //    n = n / 2;
            //}

            return arr;
        }
    }
}
